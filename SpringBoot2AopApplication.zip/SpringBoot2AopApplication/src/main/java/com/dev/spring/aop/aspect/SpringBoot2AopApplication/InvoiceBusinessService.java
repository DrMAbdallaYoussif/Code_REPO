package com.dev.spring.aop.aspect.SpringBoot2AopApplication;

import org.springframework.stereotype.Component;

import java.util.Random;


@Component
public class InvoiceBusinessService {

    public void saveInvoice() {
        System.out.println("From saveInvoice()");
        /*if(new Random().nextInt(15)<=10) {
            throw new RuntimeException("Exception occured");
        }*/
        System.out.println("Invoice Saved Successfully");
    }

    public String helloInvoice() {
        return "FROM helloInvoice()";
    }

    public void testMethodforAroundAdvice() {
        System.out.println("Business Method is getting Executed !");
    }

}
